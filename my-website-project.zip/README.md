# Modern Personal Portfolio

Created with AI Web & App Studio (AI ওয়েবসাইট ও অ্যাপ বিল্ডার)

## How to Run Locally:
Double-click `index.html` to open directly in any web browser (Chrome, Edge, Safari, Firefox). No build tools or server required!

## How to Host 100% Free Forever:
1. **Netlify Drop (Easiest)**: Visit https://app.netlify.com/drop and drag this unzipped folder directly onto the page. Your site will be live in 30 seconds with a free link!
2. **GitHub Pages**: Upload `index.html` to a GitHub repository and turn on Pages in Settings.
3. **Vercel**: Deploy via https://vercel.com/new.

Enjoy your new website!
